# Exercice 5 -> Media Queries

## - Pour des écrans plus grands que 1024px 3 carrés qui font chaqu'un 1/3 de l'écran en largeur, couleurs: 1°) rouge, 2°) vert, 3°) orange

## - Pour des écrans entre 600px et 1024px 3 carrés qui font chaqu'un 1/2 de l'écran en largeur, couleurs: 1°) rouge, 2°) vert, 3°) orange

## - Pour des écrans entre 320px et 600px 3 carrés qui font chaqu'un 2/2 de l'écran en largeur, couleurs: 1°) rouge, 2°) vert, 3°) orange